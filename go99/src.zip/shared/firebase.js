// import firebase from "firebase/compat/app"
// import "firebase/compat/auth"
// import "firebase/compat/firestore"
// import "firebase/compat/storage"
// import "firebase/compat/database"

// // const firebaseConfig = {
// //     apiKey: "AIzaSyBBeVW9GJBlFqHN337zbKOa-9k-HqPp1og",
// //     authDomain: "react-hell.firebaseapp.com",
// //     projectId: "react-hell",
// //     storageBucket: "react-hell.appspot.com",
// //     messagingSenderId: "1021225158679",
// //     appId: "1:1021225158679:web:f3f23cac4fa186a506f452",
// //     measurementId: "G-2YXY4N2P8G"
// // }

// const firebaseConfig = {
//     apiKey: "AIzaSyD-OR4IyiWH2XHkP_95kMejr1C8VuW7HoE",
//     authDomain: "second-547fb.firebaseapp.com",
//     databaseURL: "https://second-547fb-default-rtdb.firebaseio.com",
//     projectId: "second-547fb",
//     storageBucket: "second-547fb.appspot.com",
//     messagingSenderId: "561624182514",
//     appId: "1:561624182514:web:fae86de2bef7d4368c6a6b",
//     measurementId: "${config.measurementId}"
//   };

// firebase.initializeApp(firebaseConfig);

// const auth = firebase.auth();
// const apiKey = firebaseConfig.apiKey
// const firestore = firebase.firestore();
// const storage = firebase.storage()
// const realtime = firebase.database()


// export {auth,apiKey,firestore,storage,realtime}
